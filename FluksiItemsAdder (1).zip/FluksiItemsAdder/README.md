# FluksiItemsAdder
Derleme: `mvn clean package` -> target/FluksiItemsAdder-1.0.0.jar -> plugins/ klasorune at.

Komutlar:
- /arsivzip (/arşivzip, /fzip)  -> plugins/FluksiItemsAdder/output/generated.zip olusturur (ItemsAdder'daki /iazip gibi)
- /fluksi give <oyuncu> <namespace:id> [adet]
- /fluksi list | reload

Esya ekleme: plugins/FluksiItemsAdder/contents/<namespace>/items/*.yml
Model/texture: plugins/FluksiItemsAdder/contents/<namespace>/resourcepack/assets/<namespace>/{models,textures}/
