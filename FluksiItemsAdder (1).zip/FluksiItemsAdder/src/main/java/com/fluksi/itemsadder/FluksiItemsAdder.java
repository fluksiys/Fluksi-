package com.fluksi.itemsadder;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.*;

public class FluksiItemsAdder extends JavaPlugin implements TabExecutor {

    private final Map<String, ItemStack> items = new LinkedHashMap<>();
    // material -> (modelId -> model referansi)
    private final Map<Material, TreeMap<Integer, String>> overrides = new HashMap<>();
    private NamespacedKey idKey;
    private static final String PREFIX = ChatColor.AQUA + "[Fluksi] " + ChatColor.RESET;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        idKey = new NamespacedKey(this, "item_id");
        createSample();
        loadItems();
        for (String c : new String[]{"arsivzip", "fluksi"}) {
            PluginCommand pc = getCommand(c);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }
        getLogger().info(items.size() + " ozel esya yuklendi.");
    }

    private File contentsDir() { return new File(getDataFolder(), "contents"); }

    private void createSample() {
        File f = new File(contentsDir(), "fluksi/items/ornek.yml");
        if (f.exists()) return;
        f.getParentFile().mkdirs();
        new File(contentsDir(), "fluksi/resourcepack/assets/fluksi/models").mkdirs();
        new File(contentsDir(), "fluksi/resourcepack/assets/fluksi/textures").mkdirs();
        String s = "items:\n"
                + "  yakut:\n"
                + "    display_name: \"&cYakut\"\n"
                + "    lore:\n"
                + "      - \"&7Fluksi'nin ozel esyasi\"\n"
                + "    resource:\n"
                + "      material: PAPER\n"
                + "      model_id: 1001\n"
                + "      # assets/fluksi/models/yakut.json dosyasina isaret eder\n"
                + "      model_path: yakut\n";
        try { Files.writeString(f.toPath(), s, StandardCharsets.UTF_8); } catch (IOException e) { e.printStackTrace(); }
    }

    private void loadItems() {
        items.clear();
        overrides.clear();
        File[] namespaces = contentsDir().listFiles(File::isDirectory);
        if (namespaces == null) return;
        for (File ns : namespaces) {
            File[] ymls = new File(ns, "items").listFiles((d, n) -> n.endsWith(".yml"));
            if (ymls == null) continue;
            for (File y : ymls) {
                YamlConfiguration cfg = YamlConfiguration.loadConfiguration(y);
                ConfigurationSection sec = cfg.getConfigurationSection("items");
                if (sec == null) continue;
                for (String id : sec.getKeys(false)) {
                    ConfigurationSection s = sec.getConfigurationSection(id);
                    if (s == null) continue;
                    Material mat = Material.matchMaterial(s.getString("resource.material", "PAPER"));
                    if (mat == null) { getLogger().warning(ns.getName() + ":" + id + " gecersiz material"); continue; }
                    String full = ns.getName() + ":" + id;
                    ItemStack it = new ItemStack(mat);
                    ItemMeta meta = it.getItemMeta();
                    meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', s.getString("display_name", id)));
                    meta.setLore(s.getStringList("lore").stream()
                            .map(l -> ChatColor.translateAlternateColorCodes('&', l)).collect(Collectors.toList()));
                    int modelId = s.getInt("resource.model_id", 0);
                    if (modelId > 0) {
                        meta.setCustomModelData(modelId);
                        String path = s.getString("resource.model_path");
                        if (path != null) overrides.computeIfAbsent(mat, k -> new TreeMap<>())
                                .put(modelId, path.contains(":") ? path : ns.getName() + ":" + path);
                    }
                    meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, full);
                    it.setItemMeta(meta);
                    items.put(full, it);
                }
            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("arsivzip")) {
            sender.sendMessage(PREFIX + "Resource pack olusturuluyor...");
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                try {
                    File out = buildZip();
                    sender.sendMessage(PREFIX + ChatColor.GREEN + "Hazir: " + out.getPath());
                } catch (Exception e) {
                    sender.sendMessage(PREFIX + ChatColor.RED + "Hata: " + e.getMessage());
                    e.printStackTrace();
                }
            });
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(PREFIX + "/fluksi give <oyuncu> <namespace:id> [adet] | list | reload");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                reloadConfig(); loadItems();
                sender.sendMessage(PREFIX + ChatColor.GREEN + items.size() + " esya yeniden yuklendi.");
            }
            case "list" -> sender.sendMessage(PREFIX + String.join(", ", items.keySet()));
            case "give" -> {
                if (args.length < 3) { sender.sendMessage(PREFIX + "Kullanim: /fluksi give <oyuncu> <namespace:id> [adet]"); return true; }
                Player p = Bukkit.getPlayerExact(args[1]);
                ItemStack base = items.get(args[2]);
                if (p == null) { sender.sendMessage(PREFIX + ChatColor.RED + "Oyuncu bulunamadi."); return true; }
                if (base == null) { sender.sendMessage(PREFIX + ChatColor.RED + "Esya bulunamadi."); return true; }
                int amt = 1;
                if (args.length > 3) try { amt = Math.max(1, Math.min(64, Integer.parseInt(args[3]))); } catch (NumberFormatException ignored) {}
                ItemStack give = base.clone(); give.setAmount(amt);
                p.getInventory().addItem(give).values().forEach(l -> p.getWorld().dropItem(p.getLocation(), l));
                sender.sendMessage(PREFIX + ChatColor.GREEN + p.getName() + " oyuncusuna " + amt + "x " + args[2] + " verildi.");
            }
            default -> sender.sendMessage(PREFIX + "Bilinmeyen alt komut.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!c.getName().equalsIgnoreCase("fluksi")) return Collections.emptyList();
        if (a.length == 1) return Arrays.asList("give", "list", "reload");
        if (a.length == 2 && a[0].equalsIgnoreCase("give")) return null; // oyuncu isimleri
        if (a.length == 3 && a[0].equalsIgnoreCase("give"))
            return items.keySet().stream().filter(k -> k.startsWith(a[2].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }

    /** contents/<ns>/resourcepack altindakileri birlestirip zip yapar. */
    private File buildZip() throws IOException {
        File outDir = new File(getDataFolder(), "output");
        outDir.mkdirs();
        File out = new File(outDir, "generated.zip");
        Set<String> written = new HashSet<>();
        File[] namespaces = contentsDir().listFiles(File::isDirectory);

        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out), StandardCharsets.UTF_8)) {
            if (namespaces != null) for (File ns : namespaces) {
                Path root = new File(ns, "resourcepack").toPath();
                if (!Files.isDirectory(root)) continue;
                try (Stream<Path> w = Files.walk(root)) {
                    for (Path p : w.filter(Files::isRegularFile).collect(Collectors.toList())) {
                        String name = root.relativize(p).toString().replace(File.separatorChar, '/');
                        if (!written.add(name)) continue;
                        zos.putNextEntry(new ZipEntry(name));
                        Files.copy(p, zos);
                        zos.closeEntry();
                    }
                }
            }
            if (written.add("pack.mcmeta")) {
                String mc = "{\"pack\":{\"pack_format\":" + getConfig().getInt("pack_format", 22)
                        + ",\"description\":\"" + getConfig().getString("pack_description", "Fluksi").replace("\"", "'") + "\"}}";
                put(zos, "pack.mcmeta", mc);
            }
            // custom_model_data override modelleri
            for (Map.Entry<Material, TreeMap<Integer, String>> e : overrides.entrySet()) {
                String m = e.getKey().name().toLowerCase();
                String entry = "assets/minecraft/models/item/" + m + ".json";
                if (!written.add(entry)) continue;
                StringBuilder sb = new StringBuilder();
                sb.append("{\"parent\":\"item/generated\",\"textures\":{\"layer0\":\"item/").append(m).append("\"},\"overrides\":[");
                int i = 0;
                for (Map.Entry<Integer, String> o : e.getValue().entrySet()) {
                    if (i++ > 0) sb.append(',');
                    sb.append("{\"predicate\":{\"custom_model_data\":").append(o.getKey())
                      .append("},\"model\":\"").append(o.getValue()).append("\"}");
                }
                sb.append("]}");
                put(zos, entry, sb.toString());
            }
        }
        return out;
    }

    private void put(ZipOutputStream zos, String name, String content) throws IOException {
        zos.putNextEntry(new ZipEntry(name));
        zos.write(content.getBytes(StandardCharsets.UTF_8));
        zos.closeEntry();
    }
}
